Database name will be: odesk_test
Database Password is blank now
Database User is: root

You may set those in the bean.xml file exist in Web-inf\classes\bean.xml
