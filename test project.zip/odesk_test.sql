-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 29, 2014 at 09:10 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `odesk_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `bs_user`
--

CREATE TABLE IF NOT EXISTS `bs_user` (
  `USER_ID` int(3) NOT NULL AUTO_INCREMENT,
  `USER_TYPE_ID` int(2) DEFAULT NULL,
  `USER_LOGIN_ID` varchar(20) NOT NULL,
  `USER_NAME` varchar(100) DEFAULT NULL,
  `USER_PASSWORD` varchar(100) DEFAULT NULL,
  `ADDRESS` varchar(100) DEFAULT NULL,
  `CONTACT_NO` varchar(20) DEFAULT NULL,
  `ACTIVE_STATUS` int(1) DEFAULT NULL,
  `ENTRY_DT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `bs_user`
--

INSERT INTO `bs_user` (`USER_ID`, `USER_TYPE_ID`, `USER_LOGIN_ID`, `USER_NAME`, `USER_PASSWORD`, `ADDRESS`, `CONTACT_NO`, `ACTIVE_STATUS`, `ENTRY_DT`) VALUES
(1, 1, 'bsadmin', 'Mazharul', '123456', 'Bangladesh Bank', '0181895036911', 1, '2014-03-09 18:00:00'),
(2, 2, 'mazharul', 'admin2', '123456', 'sdd123', '2222222', 1, '2014-03-04 06:09:21'),
(3, 1, 'mak1234', 'Md.', NULL, 'ssss', 'ddd11', 1, '2014-04-29 09:01:28');

-- --------------------------------------------------------

--
-- Table structure for table `bs_user_type`
--

CREATE TABLE IF NOT EXISTS `bs_user_type` (
  `USER_TYPE_ID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `USER_TYPE_NAME` varchar(50) NOT NULL,
  PRIMARY KEY (`USER_TYPE_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bs_user_type`
--

INSERT INTO `bs_user_type` (`USER_TYPE_ID`, `USER_TYPE_NAME`) VALUES
(1, 'Admin'),
(2, 'End User');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
